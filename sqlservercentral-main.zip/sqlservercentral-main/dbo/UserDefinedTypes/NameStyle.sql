CREATE TYPE [dbo].[NameStyle]
    FROM BIT NOT NULL;


GO

