CREATE TYPE [dbo].[Flag]
    FROM BIT NOT NULL;


GO

